- Camdyn Zook czook@iastate.edu
- Syed Ahmad Alhussain syedal@iastate.edu
- Nithin Sebastian nithins@iastate.edu

We started off by porting Characters into a C++ class and used inheritance to make npc and pc inherit Character's characteristics
We also started to teleportation with 'g' key and then a following key press of 'r'
We lastly included the fog of war map that shows the current room the pc is in and a couple of spaces into the hallway
