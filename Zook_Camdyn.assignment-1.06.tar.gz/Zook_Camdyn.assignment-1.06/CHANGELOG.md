commit 0dfdf9b
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Mar 24 12:50:14 2021 -0500

    added teleport function

commit 2da1a6e
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Mar 24 12:40:07 2021 -0500

    Updated Readme and fog of war map

commit 5e34392
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Mar 24 12:29:32 2021 -0500

    created inheritance between npc/pc and character

commit 5f3c778
Merge: 8937ce2 2af28ea
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Mar 24 12:26:17 2021 -0500

    Merge branch 'master' of https://github.com/czook/coms327

commit 8937ce2
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Mar 24 12:26:01 2021 -0500

    started 1.06

commit 2af28ea
Author: Nitman846 <Nitman846@gmail.com>
Date:   Thu Mar 11 19:22:35 2021 -0600

    Update README

commit 03a7a87
Author: Camdyn <czook@iastate.edu>
Date:   Thu Mar 11 12:16:10 2021 -0600

    updated changlog

