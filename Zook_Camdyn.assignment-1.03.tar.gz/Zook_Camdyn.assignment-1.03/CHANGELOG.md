commit 4ade8b8
Author: czook <czook@pyrite-n1.cs.iastate.edu>
Date:   Thu Feb 25 19:34:30 2021 -0600

    final product for assignment1.03

commit 625ec95
Merge: 410c361 1a63afb
Author: Nitman846 <Nitman846@gmail.com>
Date:   Thu Feb 25 18:58:24 2021 -0600

    Merge pull request #6 from Nitman846/nithins
    
    Nithins

commit 1a63afb
Author: Nithin Sebastian <Nitman846@gmail.com>
Date:   Thu Feb 25 18:56:31 2021 -0600

    changed up comments and method names

commit 2627fb8
Merge: 0b88198 410c361
Author: Nithin Sebastian <Nitman846@gmail.com>
Date:   Thu Feb 25 18:24:34 2021 -0600

    Merge branch 'master' of https://github.com/czook/coms327

commit 410c361
Author: czook <czook@pyrite-n4.cs.iastate.edu>
Date:   Wed Feb 24 21:46:12 2021 -0600

    almost finished logic

commit 13278e6
Merge: 234baad 7814a27
Author: czook <59888557+czook@users.noreply.github.com>
Date:   Wed Feb 24 18:28:18 2021 -0600

    Merge pull request #5 from Nitman846/1.03
    
    1.03

commit 0b88198
Merge: 6878b31 7814a27
Author: Nitman846 <Nitman846@gmail.com>
Date:   Wed Feb 24 01:05:31 2021 -0600

    Merge pull request #2 from Nitman846/1.03
    
    Added methods Schaffer said to, will need some tweaking

commit 7814a27
Author: Nithin Sebastian <Nitman846@gmail.com>
Date:   Wed Feb 24 01:04:09 2021 -0600

    Added methods Schaffer said to, will need some tweaking

commit 6878b31
Merge: 12f8ca4 234baad
Author: Nitman846 <Nitman846@gmail.com>
Date:   Tue Feb 23 23:15:21 2021 -0600

    Merge pull request #1 from czook/master
    
    update fork

commit 234baad
Author: czook <czook@pyrite-n4.cs.iastate.edu>
Date:   Mon Feb 22 17:41:47 2021 -0600

    working starting point

commit 6bcaf28
Author: czook <czook@iastate.edu>
Date:   Mon Feb 22 22:25:44 2021 +0000

    Staring 3

commit 4fee7b5
Merge: e71503b d9c8542
Author: czook <czook@iastate.edu>
Date:   Mon Feb 22 22:24:06 2021 +0000

    Merge branch 'master' of https://github.com/czook/coms327

commit e71503b
Author: czook <czook@iastate.edu>
Date:   Mon Feb 22 22:23:42 2021 +0000

    Starting project 3

commit d9c8542
Author: Nitman846 <Nitman846@gmail.com>
Date:   Thu Feb 18 21:52:36 2021 -0600

    Create README.md

commit 1134819
Author: czook <czook@iastate.edu>
Date:   Fri Feb 19 00:42:53 2021 +0000

    nithin

commit 38bf7e1
Merge: aaf9970 804837f
Author: czook <czook@iastate.edu>
Date:   Fri Feb 19 00:39:13 2021 +0000

    fixed merged errors

commit aaf9970
Author: czook <czook@iastate.edu>
Date:   Fri Feb 19 00:38:20 2021 +0000

    pair programing

commit 804837f
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Thu Feb 18 18:17:19 2021 -0600

    worked on write

commit 6d74236
Author: czook <czook@iastate.edu>
Date:   Thu Feb 18 23:19:22 2021 +0000

    asdf

commit ab48638
Author: czook <czook@iastate.edu>
Date:   Thu Feb 18 18:47:21 2021 +0000

    fixed error with running on Windows

commit a04a2cf
Author: czook <czook@iastate.edu>
Date:   Thu Feb 18 15:30:30 2021 +0000

    fixing bugs in readFile

commit a3770fd
Merge: 5561de7 67d4765
Author: Nitman846 <Nitman846@gmail.com>
Date:   Thu Feb 18 02:03:29 2021 -0600

    Merge pull request #4 from Nitman846/nithins
    
    Added my changes

commit 67d4765
Author: Nithin Sebastian <Nitman846@gmail.com>
Date:   Thu Feb 18 02:01:39 2021 -0600

    Added my changes

commit 5561de7
Author: czook <czook@iastate.edu>
Date:   Thu Feb 18 02:33:58 2021 +0000

    readfile done?

commit 12f8ca4
Author: Camdyn <czook@iastate.edu>
Date:   Wed Feb 17 16:50:36 2021 -0600

    updating readFile to add every value from the table

commit 6ef9244
Merge: a4bccb9 ad30936
Author: Camdyn <czook@iastate.edu>
Date:   Wed Feb 17 16:11:47 2021 -0600

    Merge branch 'master' of https://github.com/czook/coms327

commit ad30936
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Feb 17 16:09:21 2021 -0600

    test

commit a4bccb9
Author: Camdyn <czook@iastate.edu>
Date:   Wed Feb 17 16:08:17 2021 -0600

    more updates

commit cdde8bf
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Feb 17 14:42:38 2021 -0600

    getting started on HW2

commit 9bc706d
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Feb 17 13:42:10 2021 -0600

    started the save_load.c file

commit 2800d7b
Author: Camdyn Zook <czook@iastate.edu>
Date:   Wed Feb 17 13:41:16 2021 -0600

    Revert "class notes"
    
    This reverts commit 80ef40083c6d3650941a473333c8c77362b87f0c.

commit 80ef400
Author: Camdyn Zook <czook@iastate.edu>
Date:   Tue Feb 16 11:52:41 2021 -0600

    class notes

commit 5b3990c
Author: Camdyn Zook <czook@iastate.edu>
Date:   Tue Feb 16 11:26:56 2021 -0600

    found out that his solution deals with heaps

commit ab7e6d9
Author: Camdyn <czook@iastate.edu>
Date:   Tue Feb 16 10:27:31 2021 -0600

    created assignment 1.02 folder

commit 5cfa29c
Author: Camdyn Zook <czook@iastate.edu>
Date:   Thu Feb 11 21:32:35 2021 -0600

    fixed bugs

commit 9aefff5
Author: czook <czook@iastate.edu>
Date:   Thu Feb 11 16:57:57 2021 +0000

    found errors

commit efdef96
Author: czook <czook@iastate.edu>
Date:   Thu Feb 11 16:57:15 2021 +0000

    last minute adjustments

commit 88f0cd0
Author: czook <czook@iastate.edu>
Date:   Thu Feb 11 01:01:32 2021 +0000

    updated README.md and CHANGELOG.md

commit 22ef92e
Author: czook <czook@iastate.edu>
Date:   Thu Feb 11 00:40:17 2021 +0000

    updated makefile and made header file

commit 24e0018
Author: czook <czook@iastate.edu>
Date:   Thu Feb 11 00:30:49 2021 +0000

    added stairs

commit a3c1950
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 23:15:08 2021 +0000

    updated overlapChecker()

commit 689edda
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 23:11:51 2021 +0000

    updated hallways

commit 4015084
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 23:10:44 2021 +0000

    added Hallways

commit cfc8433
Merge: ddd309a 955809a
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 22:24:00 2021 +0000

    fixed merge errors

commit ddd309a
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 22:20:26 2021 +0000

    Places rooms with spaces inbetween

commit ed6bd1e
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 22:08:34 2021 +0000

    reUpdated Make file

commit 955809a
Author: syedal <syedal@pyrite-n5.cs.iastate.edu>
Date:   Wed Feb 10 16:07:24 2021 -0600

    bug fixes

commit 0fecfd0
Author: syedal <syedal@pyrite-n5.cs.iastate.edu>
Date:   Wed Feb 10 16:04:09 2021 -0600

    fixed overlap

commit f47d83d
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Wed Feb 10 00:30:08 2021 -0600

    added comments

commit b4a2d3e
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Wed Feb 10 00:19:14 2021 -0600

    now randomly generates rooms

commit 81a72e9
Merge: c14dd95 e10ed7d
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Tue Feb 9 21:13:18 2021 -0600

    Merge branch 'master' of https://github.com/czook/coms327

commit c14dd95
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Tue Feb 9 21:12:09 2021 -0600

    aha ha

commit e10ed7d
Author: czook <czook@iastate.edu>
Date:   Wed Feb 10 02:45:53 2021 +0000

    updated makefile

commit d0d4d05
Author: syedal <syedal@pyrite-n2.cs.iastate.edu>
Date:   Tue Feb 9 19:46:57 2021 -0600

    Created border of game board

commit a35ee7b
Author: czook <czook@iastate.edu>
Date:   Tue Feb 2 19:08:01 2021 +0000

    Added Assignment1.01 folder and starting files

