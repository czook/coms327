- Camdyn Zook czook@iastate.edu
- Syed Ahmad Alhussain syedal@iastate.edu
- Nithin Sebastian nithins@iastate.edu

2/25/2021 - We used Dr. Scheaffer's code for project 1.02 and we added two different dijkstra's algorithms to calculate a path from any given
point on the map. One for tunneling monsters and one for nontunneling monsters. Also we created new maps inside the dunegon struct that are
being used to print the 2 other maps.
