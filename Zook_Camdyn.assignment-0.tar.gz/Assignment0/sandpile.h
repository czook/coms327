void inputVals(int grid[23][23],int x, int y, int h);
void worldGen(int grid[23][23]);
void printWorld(int grid[23][23]);
int pilefall(int x, int y, int grid[23][23]);
