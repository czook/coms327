- Camdyn Zook czook@iastate.edu
- Syed Ahmad Alhussain syedal@iastate.edu
- Nithin Sebastian nithins@iastate.edu

This program implements a modified version of the abelian sandpile model. In essence, we have a user pass in a triplet tuple, with the y x and h argurments being passed in to create a sandpile at a distinct location. Anytime the pile exceeds a height of 8, the pile recursively gives a grain to each of it's neighbors. 
