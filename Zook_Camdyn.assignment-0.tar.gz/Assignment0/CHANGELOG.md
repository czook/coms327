ff517bd (HEAD -> master, origin/master) fixed bugs and added header to makefile
175a9f2 simple makefile
5ca6213 removed stackdump
bfa43e1 updated for sandpile.h
42db8da README.md file change
28fc32d Merge remote-tracking branch 'origin/Nitman846-patch-2'
79a083d (origin/Nitman846-patch-2) Update README.txt
4e40f8b Create README.txt
b631f3e (origin/Nitman846-patch-1) Create sandpile.h
20b2a33 added the fps
00892b7 Working program :)
d12b1cb still random stopping bug
d204d2e recursive method isn't working
895c66a added all of the methods
761c7bb more work
a0b2d2f no errors
e728378 getting started on progress
b3c9cf5 hello world
65220f9 first commit
